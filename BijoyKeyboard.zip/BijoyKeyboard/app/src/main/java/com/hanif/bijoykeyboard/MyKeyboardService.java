package com.hanif.bijoykeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import androidx.annotation.NonNull;

public class MyKeyboardService extends InputMethodService {

    private String pendingVowel = "";
    private String pendingRef = "";
    private boolean isG_Pressed = false;
    private boolean isEnglishMode = false;
    private boolean isShiftPressed = false;
    private boolean isSymbolMode = false;
    private boolean isCtrlActive = false; // অন-স্ক্রিন শর্টকাট ট্র্যাকিংয়ের জন্য

    private View keyboardView;

    @Override
    public View onCreateInputView() {
        keyboardView = getLayoutInflater().inflate(R.layout.keyboard_layout, null);
        setupKeyboard();
        updateKeyLabels();
        return keyboardView;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        updateClipboardItems();
        isCtrlActive = false; 
    }

    private void updateClipboardItems() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip()) {
            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
            if (item != null && item.getText() != null) {
                String text = item.getText().toString();
                Button btnClipboard = keyboardView.findViewById(R.id.btn_clip_item);
                if (btnClipboard != null) {
                    String displayText = text.length() > 10 ? text.substring(0, 10) + "..." : text;
                    btnClipboard.setText(displayText);
                    btnClipboard.setOnClickListener(v -> {
                        InputConnection ic = getCurrentInputConnection();
                        if (ic != null) ic.commitText(text, 1);
                    });
                }
            }
        }
    }

    private void setupKeyboard() {
        int[] buttonIds = {
                R.id.btn_q, R.id.btn_w, R.id.btn_e, R.id.btn_r, R.id.btn_t, R.id.btn_y, R.id.btn_u, R.id.btn_i, R.id.btn_o, R.id.btn_p,
                R.id.btn_a, R.id.btn_s, R.id.btn_d, R.id.btn_f, R.id.btn_g, R.id.btn_h, R.id.btn_j, R.id.btn_k, R.id.btn_l,
                R.id.btn_z, R.id.btn_x, R.id.btn_c, R.id.btn_v, R.id.btn_b, R.id.btn_n, R.id.btn_m,
                R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_0
        };

        for (int id : buttonIds) {
            Button btn = keyboardView.findViewById(id);
            if (btn != null) {
                btn.setOnClickListener(v -> {
                    Object tagObj = v.getTag();
                    if (tagObj != null) {
                        String tag = tagObj.toString();
                        handleOnScreenKey(tag);
                    }
                });
            }
        }

        // অন-স্ক্রিন কন্ট্রোল বাটনের লজিক (যদি লেআউটে থাকে)
        Button btnCtrl = keyboardView.findViewById(R.id.btn_ctrl);
        if (btnCtrl != null) {
            btnCtrl.setOnClickListener(v -> {
                isCtrlActive = !isCtrlActive;
                updateCtrlButtonState();
            });
        }

        keyboardView.findViewById(R.id.btn_comma).setOnClickListener(v -> {
            getCurrentInputConnection().commitText(",", 1);
            resetStates();
        });

        keyboardView.findViewById(R.id.btn_period).setOnClickListener(v -> {
            getCurrentInputConnection().commitText(".", 1);
            resetStates();
        });

        keyboardView.findViewById(R.id.btn_shift).setOnClickListener(v -> {
            isShiftPressed = !isShiftPressed;
            updateKeyLabels();
            v.setAlpha(isShiftPressed ? 0.5f : 1.0f);
        });

        keyboardView.findViewById(R.id.btn_lang).setOnClickListener(v -> {
            isEnglishMode = !isEnglishMode;
            isSymbolMode = false;
            updateKeyLabels();
            resetStates();
        });

        keyboardView.findViewById(R.id.btn_symbol).setOnClickListener(v -> {
            isSymbolMode = !isSymbolMode;
            updateKeyLabels();
        });

        keyboardView.findViewById(R.id.btn_space).setOnClickListener(v -> {
            getCurrentInputConnection().commitText(" ", 1);
            resetStates();
        });

        Button btnDel = keyboardView.findViewById(R.id.btn_del);
        btnDel.setOnClickListener(v -> {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) {
                CharSequence selectedText = ic.getSelectedText(0);
                if (selectedText != null && selectedText.length() > 0) {
                    ic.commitText("", 1);
                } else {
                    ic.deleteSurroundingText(1, 0);
                }
            }
            resetStates();
        });

        keyboardView.findViewById(R.id.btn_enter).setOnClickListener(v -> {
            getCurrentInputConnection().sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
            resetStates();
        });
    }

    private void updateCtrlButtonState() {
        Button btnCtrl = keyboardView.findViewById(R.id.btn_ctrl);
        if (btnCtrl != null) {
            btnCtrl.setAlpha(isCtrlActive ? 0.5f : 1.0f);
        }
    }

    private String getSymbol(String tag) {
        switch (tag) {
            case "q": return "1"; case "w": return "2"; case "e": return "3"; case "r": return "4";
            case "t": return "5"; case "y": return "6"; case "u": return "7"; case "i": return "8";
            case "o": return "9"; case "p": return "0";
            case "a": return "@"; case "s": return "#"; case "d": return "$"; case "f": return "_";
            case "g": return "&"; case "h": return "-"; case "j": return "+"; case "k": return "(";
            case "l": return ")";
            case "z": return "*"; case "x": return "\""; case "c": return "'"; case "v": return ":";
            case "b": return ";"; case "n": return "!"; case "m": return "?";
            default: return "";
        }
    }

    private void updateKeyLabels() {
        int[] buttonIds = {
                R.id.btn_q, R.id.btn_w, R.id.btn_e, R.id.btn_r, R.id.btn_t, R.id.btn_y, R.id.btn_u, R.id.btn_i, R.id.btn_o, R.id.btn_p,
                R.id.btn_a, R.id.btn_s, R.id.btn_d, R.id.btn_f, R.id.btn_g, R.id.btn_h, R.id.btn_j, R.id.btn_k, R.id.btn_l,
                R.id.btn_z, R.id.btn_x, R.id.btn_c, R.id.btn_v, R.id.btn_b, R.id.btn_n, R.id.btn_m
        };

        for (int id : buttonIds) {
            Button btn = keyboardView.findViewById(id);
            if (btn != null && btn.getTag() != null) {
                String tag = btn.getTag().toString();
                if (isSymbolMode) {
                    btn.setText(getSymbol(tag));
                } else if (isEnglishMode) {
                    btn.setText(isShiftPressed ? tag.toUpperCase() : tag.toLowerCase());
                } else {
                    if (tag.equals("x")) {
                        btn.setText(isShiftPressed ? "\u09CC" : "\u0993");
                    } else {
                        btn.setText(Bijoymaper.getUnicode(tag, isShiftPressed));
                    }
                }
            }
        }
        Button langBtn = keyboardView.findViewById(R.id.btn_lang);
        if (langBtn != null) langBtn.setText(isEnglishMode ? "Eng" : "বাং");
    }

    private void handleOnScreenKey(String tag) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        // অন-স্ক্রিন কিবোর্ডের জন্য Ctrl শর্টকাট চেক
        if (isCtrlActive) {
            boolean handled = false;
            switch (tag) {
                case "a": ic.performContextMenuAction(android.R.id.selectAll); handled = true; break;
                case "c": ic.performContextMenuAction(android.R.id.copy); handled = true; break;
                case "v": ic.performContextMenuAction(android.R.id.paste); handled = true; break;
                case "x": ic.performContextMenuAction(android.R.id.cut); handled = true; break;
            }
            if (handled) {
                isCtrlActive = false;
                updateCtrlButtonState();
                return;
            }
        }

        if (isSymbolMode) { ic.commitText(getSymbol(tag), 1); return; }
        if (isEnglishMode) {
            ic.commitText(isShiftPressed ? tag.toUpperCase() : tag.toLowerCase(), 1);
        } else {
            String result = Bijoymaper.getUnicode(tag, isShiftPressed);
            processBengaliLogic(result, ic);
        }
        
        if (isShiftPressed) {
            isShiftPressed = false;
            updateKeyLabels();
            View shiftBtn = keyboardView.findViewById(R.id.btn_shift);
            if (shiftBtn != null) shiftBtn.setAlpha(1.0f);
        }
    }

    private void processBengaliLogic(String result, InputConnection ic) {
        if (result == null || result.isEmpty()) return;

        if (isG_Pressed && result.equals("\u09C3")) {
            ic.commitText("\u098B", 1);
            isG_Pressed = false;
            return;
        }

        if (result.equals("\u09CD\u09AF")) {
            String prev = getPreviousChar(ic);
            if (prev.equals("\u09B0")) {
                ic.commitText("\u200D" + result, 1);
                isG_Pressed = false;
                return;
            }
        }

        if (result.equals("\u09B0\u09CD")) {
            pendingRef = result;
            return;
        }

        if (result.equals("\u09CD")) {
            isG_Pressed = true;
            return;
        }

        boolean isKar = isBengaliKar(result);

        if (isG_Pressed) {
            if (isKar) {
                ic.commitText(convertKarToVowel(result), 1);
            } else {
                String prev = getPreviousChar(ic);
                ic.deleteSurroundingText(1, 0);
                ic.commitText(prev + "\u09CD" + result, 1);

                if (!pendingVowel.isEmpty()) {
                    ic.commitText(pendingVowel, 1);
                    pendingVowel = "";
                }
            }
            isG_Pressed = false;
            return;
        }

        if (isKar && (result.equals("\u09BF") || result.equals("\u09C7") || result.equals("\u09C8"))) {
            pendingVowel = result;
            return;
        }

        if (!isKar) {
            String toCommit = result;
            if (!pendingRef.isEmpty()) {
                toCommit = pendingRef + result;
                pendingRef = "";
            }
            ic.commitText(toCommit, 1);

            if (!pendingVowel.isEmpty()) {
                ic.commitText(pendingVowel, 1);
                pendingVowel = "";
            }
        } else {
            ic.commitText(result, 1);
        }
        isG_Pressed = false;
    }

    @Override
    public boolean onKeyDown(int keyCode, @NonNull KeyEvent event) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return super.onKeyDown(keyCode, event);

        // ফিজিক্যাল/এক্সটার্নাল কিবোর্ড কন্ট্রোল শর্টকাট (A, C, V, X, F, H)
        if (event.isCtrlPressed()) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_A: ic.performContextMenuAction(android.R.id.selectAll); return true;
                case KeyEvent.KEYCODE_C: ic.performContextMenuAction(android.R.id.copy); return true;
                case KeyEvent.KEYCODE_V: ic.performContextMenuAction(android.R.id.paste); return true;
                case KeyEvent.KEYCODE_X: ic.performContextMenuAction(android.R.id.cut); return true;
                case KeyEvent.KEYCODE_F: ic.performContextMenuAction(android.R.id.startSelectingText); return true;
                case KeyEvent.KEYCODE_H: ic.performContextMenuAction(android.R.id.replaceText); return true;
            }
        }

        if (keyCode == KeyEvent.KEYCODE_DEL) {
            resetStates();
            return super.onKeyDown(keyCode, event);
        }

        if (event.isAltPressed() && keyCode == KeyEvent.KEYCODE_SPACE) {
            isEnglishMode = !isEnglishMode;
            resetStates();
            updateKeyLabels();
            return true;
        }

        if (isEnglishMode) return super.onKeyDown(keyCode, event);

        if (event.isPrintingKey()) {
            char keyChar = (char) event.getUnicodeChar();
            String tag = String.valueOf(keyChar).toLowerCase();
            boolean shift = event.isShiftPressed();
            String result = Bijoymaper.getUnicode(tag, shift);
            if (result != null && !result.isEmpty()) {
                processBengaliLogic(result, ic);
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private void resetStates() { 
        pendingVowel = ""; 
        pendingRef = ""; 
        isG_Pressed = false; 
        isCtrlActive = false; 
        updateCtrlButtonState();
    }
    
    private boolean isBengaliKar(String s) { return "\u09BE\u09BF\u09C0\u09C1\u09C2\u09C3\u09C7\u09C8\u09CB\u09CC".contains(s); }
    
    private String convertKarToVowel(String kar) {
        switch (kar) {
            case "\u09BE": return "\u0986"; case "\u09BF": return "\u0987";
            case "\u09C0": return "\u0988"; case "\u09C1": return "\u0989";
            case "\u09C2": return "\u098A"; case "\u09C3": return "\u098B";
            case "\u09C7": return "\u098F"; case "\u09C8": return "\u0990";
            case "\u09CB": return "\u0993"; case "\u09CC": return "\u0994";
            default: return kar;
        }
    }
    
    private String getPreviousChar(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(1, 0);
        return (before != null) ? before.toString() : "";
    }
}
